# Ansible Collection - vp_netology.learn_ansible

Тестовая коллекция для изучения Ansible